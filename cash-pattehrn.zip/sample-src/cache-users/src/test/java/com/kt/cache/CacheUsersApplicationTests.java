package com.kt.cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CacheUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
