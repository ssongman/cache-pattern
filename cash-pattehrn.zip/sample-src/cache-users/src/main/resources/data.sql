insert into users(user_id, user_name, age, height) values('USER-0001', 'Song', 50, 175);
insert into users(user_id, user_name, age, height) values('USER-0002', 'Kim', 55, 180);
insert into users(user_id, user_name, age, height) values('USER-0003', 'Lee', 60, 185);
