package com.kt.cache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CacheUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(CacheUsersApplication.class, args);
	}

}
